@echo off
chcp 65001 >nul
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0Repair-Now.ps1" -RequestedAction Apply -UiLanguage en
pause
